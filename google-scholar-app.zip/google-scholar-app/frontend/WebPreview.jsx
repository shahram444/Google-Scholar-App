import React, { useState } from 'react';

// Mock data for demonstration
const MOCK_SCHOLAR_DATA = {
  profile: {
    name: "Shahram Vahdati",
    affiliation: "PhD Candidate, University of Georgia",
    profileImage: "https://scholar.google.com/citations/images/avatar_scholar_128.png",
    interests: ["Pore-scale modeling", "Reactive transport", "Lattice Boltzmann methods"],
    scholarId: "demo123",
  },
  stats: {
    totalCitations: 247,
    citationsSince: 198,
    hIndex: 8,
    hIndexSince: 7,
    i10Index: 6,
    i10IndexSince: 5,
  },
  citationHistory: [
    { year: 2018, citations: 12 },
    { year: 2019, citations: 28 },
    { year: 2020, citations: 41 },
    { year: 2021, citations: 52 },
    { year: 2022, citations: 48 },
    { year: 2023, citations: 39 },
    { year: 2024, citations: 27 },
  ],
  publications: [
    { title: "Dimensional effects on breakthrough behavior and pore-scale residence time distributions", authors: "S Vahdati, H Jung, C Meile", venue: "Transport in Porous Media", citations: 45, year: "2024" },
    { title: "CompLaB3D: A 3D pore-scale reactive transport simulator using lattice Boltzmann methods", authors: "S Vahdati, C Meile", venue: "Computational Geosciences", citations: 38, year: "2023" },
    { title: "Microbial distribution in soil aggregates: A pore-scale modeling approach", authors: "S Vahdati, C Meile", venue: "Soil Biology and Biochemistry", citations: 32, year: "2023" },
    { title: "Carbonate structure and anaerobic oxidation of methane in deep-sea environments", authors: "S Vahdati, H Jung, C Meile", venue: "Geochimica et Cosmochimica Acta", citations: 28, year: "2022" },
    { title: "CompLaB Studio: A GUI for simplified simulation setup", authors: "S Vahdati", venue: "SoftwareX", citations: 24, year: "2024" },
  ],
  coAuthors: [
    { name: "Dr. Christof Meile", affiliation: "University of Georgia", image: "https://via.placeholder.com/60/4fc3f7/fff?text=CM" },
    { name: "Dr. Heewon Jung", affiliation: "Chungnam National University", image: "https://via.placeholder.com/60/81c784/fff?text=HJ" },
    { name: "Dr. Ming Ye", affiliation: "Florida State University", image: "https://via.placeholder.com/60/ffb74d/fff?text=MY" },
  ],
};

// Icons as SVG components
const Icons = {
  School: () => (
    <svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M22 10v6M2 10l10-5 10 5-10 5z"/>
      <path d="M6 12v5c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2v-5"/>
    </svg>
  ),
  Stats: () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M18 20V10M12 20V4M6 20v-6"/>
    </svg>
  ),
  Document: () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
      <path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"/>
    </svg>
  ),
  Bell: () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0"/>
    </svg>
  ),
  Bookmark: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
      <path d="M19 21l-7-5-7 5V5a2 2 0 012-2h10a2 2 0 012 2z"/>
    </svg>
  ),
  TrendingUp: () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M23 6l-9.5 9.5-5-5L1 18"/>
      <path d="M17 6h6v6"/>
    </svg>
  ),
  Star: () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
    </svg>
  ),
  Logout: () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/>
    </svg>
  ),
  Refresh: () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M23 4v6h-6M1 20v-6h6"/>
      <path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/>
    </svg>
  ),
  Search: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#666" strokeWidth="2">
      <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
    </svg>
  ),
  ChevronRight: () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#666" strokeWidth="2">
      <path d="M9 18l6-6-6-6"/>
    </svg>
  ),
};

// Components
const StatCard = ({ icon: Icon, label, value, subValue, color }) => (
  <div style={{
    display: 'flex',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: '16px',
    padding: '15px',
    marginBottom: '10px',
    borderLeft: `4px solid ${color}`,
  }}>
    <div style={{
      width: '50px',
      height: '50px',
      borderRadius: '50%',
      backgroundColor: 'rgba(255,255,255,0.1)',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      color: color,
    }}>
      <Icon />
    </div>
    <div style={{ marginLeft: '15px' }}>
      <p style={{ fontSize: '28px', fontWeight: '700', margin: '0' }}>{value?.toLocaleString() || '—'}</p>
      <span style={{ color: 'rgba(255,255,255,0.7)', fontSize: '14px' }}>{label}</span>
      {subValue && <div style={{ color: '#81c784', fontSize: '12px', marginTop: '2px' }}>+{subValue} (5 years)</div>}
    </div>
  </div>
);

const CitationGraph = ({ data }) => {
  if (!data?.length) return null;
  const maxCitations = Math.max(...data.map(d => d.citations));
  
  return (
    <div style={{
      backgroundColor: 'rgba(255,255,255,0.1)',
      borderRadius: '16px',
      padding: '15px',
      marginBottom: '20px',
    }}>
      <h3 style={{ fontSize: '18px', fontWeight: '700', margin: '0 0 15px 0' }}>Citation History</h3>
      <div style={{ display: 'flex', alignItems: 'flex-end', height: '120px', gap: '4px' }}>
        {data.map((item, index) => (
          <div key={item.year} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <div style={{
              width: '80%',
              borderRadius: '4px',
              minHeight: '4px',
              height: `${(item.citations / maxCitations) * 100}%`,
              backgroundColor: `hsl(${200 + index * 15}, 70%, 60%)`,
              transition: 'height 0.3s',
            }} />
            <span style={{ color: 'rgba(255,255,255,0.5)', fontSize: '10px', marginTop: '5px' }}>{item.year.toString().slice(-2)}</span>
            <span style={{ color: '#fff', fontSize: '9px', marginTop: '2px' }}>{item.citations}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

// Main App
export default function App() {
  const [screen, setScreen] = useState('login');
  const [user, setUser] = useState(null);
  const [scholarData, setScholarData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [scholarId, setScholarId] = useState('');
  const [searchResults, setSearchResults] = useState([]);

  const handleLogin = () => {
    setLoading(true);
    setTimeout(() => {
      setUser({
        name: 'Shahram Vahdati',
        email: 'shahram@uga.edu',
        picture: 'https://via.placeholder.com/80/4fc3f7/fff?text=SV',
      });
      setScreen('link');
      setLoading(false);
    }, 1500);
  };

  const handleSearch = () => {
    if (!searchQuery.trim()) return;
    setLoading(true);
    setTimeout(() => {
      setSearchResults([{
        scholarId: 'demo123',
        name: 'Shahram Vahdati',
        affiliation: 'University of Georgia',
        citations: 247,
        image: 'https://via.placeholder.com/50/4fc3f7/fff?text=SV',
      }]);
      setLoading(false);
    }, 1000);
  };

  const handleLinkScholar = (id) => {
    setLoading(true);
    setTimeout(() => {
      setScholarData(MOCK_SCHOLAR_DATA);
      setScreen('dashboard');
      setLoading(false);
    }, 1500);
  };

  const handleRefresh = () => {
    setLoading(true);
    setTimeout(() => setLoading(false), 1000);
  };

  const handleLogout = () => {
    setUser(null);
    setScholarData(null);
    setSearchResults([]);
    setSearchQuery('');
    setScholarId('');
    setScreen('login');
  };

  const containerStyle = {
    minHeight: '100vh',
    background: 'linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%)',
    fontFamily: "'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif",
    color: '#fff',
    overflow: 'auto',
  };

  const loadingOverlay = loading && (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0,0,0,0.7)',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      zIndex: 100,
    }}>
      <div style={{
        width: '40px',
        height: '40px',
        border: '3px solid rgba(255,255,255,0.3)',
        borderTopColor: '#fff',
        borderRadius: '50%',
        animation: 'spin 1s linear infinite',
      }} />
      <p style={{ marginTop: '15px', fontSize: '16px' }}>Loading...</p>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );

  // Login Screen
  if (screen === 'login') {
    return (
      <div style={containerStyle}>
        <div style={{
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          padding: '30px',
        }}>
          <div style={{ textAlign: 'center', marginBottom: '50px' }}>
            <div style={{
              width: '120px',
              height: '120px',
              borderRadius: '60px',
              backgroundColor: 'rgba(255,255,255,0.15)',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              margin: '0 auto 20px',
            }}>
              <Icons.School />
            </div>
            <h1 style={{ fontSize: '36px', fontWeight: '700', letterSpacing: '1px', margin: '0' }}>Scholar Hub</h1>
            <p style={{ fontSize: '16px', color: 'rgba(255,255,255,0.7)', marginTop: '8px' }}>Track your academic impact</p>
          </div>

          <div style={{ marginBottom: '40px' }}>
            {[
              { Icon: Icons.Stats, color: '#4fc3f7', text: 'Citation metrics & h-index' },
              { Icon: Icons.Document, color: '#81c784', text: 'Publication tracking' },
              { Icon: Icons.Bell, color: '#ffb74d', text: 'New citation alerts' },
            ].map(({ Icon, color, text }, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', margin: '12px 0', gap: '15px' }}>
                <span style={{ color }}><Icon /></span>
                <span>{text}</span>
              </div>
            ))}
          </div>

          <button
            onClick={handleLogin}
            disabled={loading}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              backgroundColor: '#fff',
              color: '#333',
              border: 'none',
              padding: '14px 30px',
              borderRadius: '30px',
              fontSize: '16px',
              fontWeight: '600',
              cursor: 'pointer',
              boxShadow: '0 4px 15px rgba(0,0,0,0.2)',
            }}
          >
            <img src="https://www.google.com/favicon.ico" width="24" height="24" alt="Google" />
            {loading ? 'Signing in...' : 'Sign in with Google'}
          </button>

          <p style={{
            marginTop: '30px',
            textAlign: 'center',
            color: 'rgba(255,255,255,0.5)',
            fontSize: '12px',
            lineHeight: '1.5',
          }}>
            We only access your basic Google profile.<br />
            Your Scholar data is fetched separately.
          </p>
        </div>
        {loadingOverlay}
      </div>
    );
  }

  // Link Scholar Screen
  if (screen === 'link') {
    return (
      <div style={containerStyle}>
        <div style={{ padding: '60px 20px 20px', maxWidth: '500px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '30px' }}>
            <img src={user.picture} alt={user.name} style={{
              width: '80px',
              height: '80px',
              borderRadius: '50%',
              border: '3px solid #fff',
            }} />
            <p style={{ fontSize: '20px', fontWeight: '600', marginTop: '15px' }}>Welcome, {user.name}!</p>
          </div>

          <h2 style={{ fontSize: '24px', fontWeight: '700', textAlign: 'center', margin: '0' }}>Link Your Google Scholar</h2>
          <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: '14px', textAlign: 'center', marginTop: '8px', marginBottom: '25px' }}>
            Search for your profile or enter your Scholar ID directly
          </p>

          <div style={{
            display: 'flex',
            alignItems: 'center',
            backgroundColor: 'rgba(255,255,255,0.1)',
            borderRadius: '12px',
            padding: '0 15px',
            marginBottom: '20px',
          }}>
            <Icons.Search />
            <input
              type="text"
              placeholder="Search by name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              style={{
                flex: 1,
                background: 'transparent',
                border: 'none',
                color: '#fff',
                fontSize: '16px',
                padding: '15px 10px',
                outline: 'none',
              }}
            />
            <button onClick={handleSearch} style={{
              backgroundColor: '#4fc3f7',
              color: '#fff',
              border: 'none',
              padding: '10px 20px',
              borderRadius: '8px',
              cursor: 'pointer',
              fontWeight: '600',
            }}>
              Search
            </button>
          </div>

          {searchResults.length > 0 && (
            <div>
              <p style={{ color: '#fff', marginBottom: '10px', fontWeight: '600' }}>Found Profiles:</p>
              {searchResults.map((profile) => (
                <div
                  key={profile.scholarId}
                  onClick={() => handleLinkScholar(profile.scholarId)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    backgroundColor: 'rgba(255,255,255,0.1)',
                    padding: '15px',
                    borderRadius: '12px',
                    marginBottom: '10px',
                    cursor: 'pointer',
                  }}
                >
                  <img src={profile.image} alt={profile.name} style={{ width: '50px', height: '50px', borderRadius: '50%' }} />
                  <div style={{ flex: 1, marginLeft: '15px' }}>
                    <p style={{ fontWeight: '600', fontSize: '16px', margin: 0 }}>{profile.name}</p>
                    <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: '12px', marginTop: '2px' }}>{profile.affiliation}</p>
                    <p style={{ color: '#4fc3f7', fontSize: '12px', marginTop: '4px' }}>{profile.citations.toLocaleString()} citations</p>
                  </div>
                  <Icons.ChevronRight />
                </div>
              ))}
            </div>
          )}

          <div style={{ display: 'flex', alignItems: 'center', margin: '25px 0' }}>
            <div style={{ flex: 1, height: '1px', backgroundColor: 'rgba(255,255,255,0.2)' }} />
            <span style={{ color: 'rgba(255,255,255,0.5)', margin: '0 15px', fontSize: '14px' }}>OR</span>
            <div style={{ flex: 1, height: '1px', backgroundColor: 'rgba(255,255,255,0.2)' }} />
          </div>

          <p style={{ color: '#fff', fontSize: '14px', marginBottom: '10px' }}>Enter Scholar ID directly:</p>
          <div style={{ display: 'flex', gap: '10px' }}>
            <input
              type="text"
              placeholder="e.g., ABC123xyz"
              value={scholarId}
              onChange={(e) => setScholarId(e.target.value)}
              style={{
                flex: 1,
                backgroundColor: 'rgba(255,255,255,0.1)',
                border: 'none',
                color: '#fff',
                fontSize: '16px',
                padding: '15px',
                borderRadius: '12px',
                outline: 'none',
              }}
            />
            <button
              onClick={() => scholarId && handleLinkScholar(scholarId)}
              disabled={!scholarId}
              style={{
                backgroundColor: '#81c784',
                color: '#fff',
                border: 'none',
                padding: '15px 25px',
                borderRadius: '12px',
                cursor: scholarId ? 'pointer' : 'not-allowed',
                fontWeight: '600',
                fontSize: '16px',
                opacity: scholarId ? 1 : 0.5,
              }}
            >
              Link
            </button>
          </div>

          <p style={{
            color: 'rgba(255,255,255,0.5)',
            fontSize: '12px',
            textAlign: 'center',
            marginTop: '20px',
            lineHeight: '1.6',
          }}>
            Find your Scholar ID in your profile URL:<br />
            scholar.google.com/citations?user=<span style={{ color: '#4fc3f7', fontWeight: '600' }}>YOUR_ID</span>
          </p>
        </div>
        {loadingOverlay}
      </div>
    );
  }

  // Dashboard Screen
  const { profile, stats, citationHistory, publications, coAuthors } = scholarData || {};

  return (
    <div style={containerStyle}>
      <div style={{ padding: '50px 20px 20px', maxWidth: '600px', margin: '0 auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
          <button onClick={handleLogout} style={{
            background: 'transparent',
            border: 'none',
            color: '#fff',
            cursor: 'pointer',
            padding: '10px',
            opacity: 0.8,
          }}>
            <Icons.Logout />
          </button>
          <button onClick={handleRefresh} style={{
            background: 'transparent',
            border: 'none',
            color: '#fff',
            cursor: 'pointer',
            padding: '10px',
            opacity: 0.8,
          }}>
            <Icons.Refresh />
          </button>
        </div>

        {/* Profile Card */}
        <div style={{
          display: 'flex',
          backgroundColor: 'rgba(255,255,255,0.1)',
          borderRadius: '20px',
          padding: '20px',
          marginBottom: '20px',
          gap: '15px',
        }}>
          <img
            src={profile?.profileImage || user.picture}
            alt={profile?.name}
            style={{
              width: '80px',
              height: '80px',
              borderRadius: '50%',
              border: '3px solid #4fc3f7',
              objectFit: 'cover',
            }}
          />
          <div style={{ flex: 1 }}>
            <h2 style={{ fontSize: '20px', fontWeight: '700', margin: '0' }}>{profile?.name || user.name}</h2>
            <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: '13px', marginTop: '4px' }}>{profile?.affiliation}</p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginTop: '10px' }}>
              {profile?.interests?.slice(0, 3).map((interest, i) => (
                <span key={i} style={{
                  backgroundColor: 'rgba(79,195,247,0.3)',
                  color: '#4fc3f7',
                  padding: '4px 10px',
                  borderRadius: '12px',
                  fontSize: '11px',
                }}>{interest}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Stats */}
        <div style={{ marginBottom: '20px' }}>
          <StatCard icon={Icons.Bookmark} label="Total Citations" value={stats?.totalCitations} subValue={stats?.citationsSince} color="#4fc3f7" />
          <StatCard icon={Icons.TrendingUp} label="h-index" value={stats?.hIndex} subValue={stats?.hIndexSince} color="#81c784" />
          <StatCard icon={Icons.Star} label="i10-index" value={stats?.i10Index} subValue={stats?.i10IndexSince} color="#ffb74d" />
        </div>

        {/* Citation Graph */}
        <CitationGraph data={citationHistory} />

        {/* Publications */}
        <div style={{ marginBottom: '20px' }}>
          <h3 style={{ fontSize: '18px', fontWeight: '700', margin: '0 0 15px 0' }}>Top Publications</h3>
          {publications?.map((pub, index) => (
            <div key={index} style={{
              display: 'flex',
              backgroundColor: 'rgba(255,255,255,0.08)',
              borderRadius: '12px',
              padding: '12px',
              marginBottom: '10px',
              cursor: 'pointer',
            }}>
              <div style={{
                width: '30px',
                height: '30px',
                borderRadius: '50%',
                backgroundColor: 'rgba(255,255,255,0.1)',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                fontSize: '12px',
                fontWeight: '600',
                flexShrink: 0,
              }}>{index + 1}</div>
              <div style={{ flex: 1, marginLeft: '12px', minWidth: 0 }}>
                <p style={{ fontSize: '14px', fontWeight: '600', lineHeight: '1.4', margin: '0' }}>{pub.title}</p>
                <p style={{ color: 'rgba(255,255,255,0.6)', fontSize: '12px', marginTop: '4px' }}>{pub.authors}</p>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '8px' }}>
                  <span style={{ color: 'rgba(255,255,255,0.5)', fontSize: '11px', flex: 1 }}>{pub.venue}</span>
                  <span style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px',
                    backgroundColor: 'rgba(255,215,0,0.2)',
                    padding: '3px 8px',
                    borderRadius: '10px',
                    color: '#ffd700',
                    fontSize: '12px',
                    fontWeight: '600',
                  }}>
                    <Icons.Bookmark />
                    {pub.citations}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Co-Authors */}
        {coAuthors?.length > 0 && (
          <div style={{ marginBottom: '20px' }}>
            <h3 style={{ fontSize: '18px', fontWeight: '700', margin: '0 0 15px 0' }}>Co-Authors</h3>
            <div style={{ display: 'flex', gap: '15px', overflowX: 'auto', paddingBottom: '10px' }}>
              {coAuthors.map((coAuthor, index) => (
                <div key={index} style={{
                  width: '100px',
                  flexShrink: 0,
                  textAlign: 'center',
                  padding: '10px',
                  backgroundColor: 'rgba(255,255,255,0.08)',
                  borderRadius: '12px',
                  cursor: 'pointer',
                }}>
                  <img src={coAuthor.image} alt={coAuthor.name} style={{
                    width: '50px',
                    height: '50px',
                    borderRadius: '50%',
                    marginBottom: '8px',
                  }} />
                  <p style={{ fontSize: '12px', fontWeight: '600', margin: 0 }}>{coAuthor.name}</p>
                  <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '10px', marginTop: '4px' }}>{coAuthor.affiliation}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        <div style={{ height: '50px' }} />
      </div>
      {loadingOverlay}
    </div>
  );
}
